package main;

import static org.junit.Assert.*;


import org.junit.Test;

public class tests {

	@Test
	public void testHighCadenceTimeInput() {
		MainProgram tester = new MainProgram();
		tester.setHighTime(10);
		assertEquals("High Cadence must have been set to 10", 10, tester.getHighTime());
	}
	
	@Test
	public void testMediumCadenceTimeInput() {
		MainProgram tester = new MainProgram();
		tester.setMediumTime(10);
		assertEquals("Medium Cadence must have been set to 10", 10, tester.getMediumTime());
	}

	@Test
	public void testLowCadenceTimeInput() {
		MainProgram tester = new MainProgram();
		tester.setLowTime(10);
		assertEquals("Medium Cadence must have been set to 10", 10, tester.getLowTime());
	}
	
	@Test
	public void testHighCadenceSelection() {
		MainProgram tester = new MainProgram();
		tester.setCadence(3);
		assertEquals("Cadence must have been set to High", "HIGH", tester.getCadence());
	}
	
	@Test
	public void testMediumCadenceSelection() {
		MainProgram tester = new MainProgram();
		tester.setCadence(2);
		assertEquals("Cadence must have been set to MEDIUM", "MEDIUM", tester.getCadence());
	}
	
	@Test
	public void testLowCadenceSelection() {
		MainProgram tester = new MainProgram();
		tester.setCadence(1);
		assertEquals("Cadence must have been set to LOW", "LOW", tester.getCadence());
	}
	
	@Test
	public void testWorkoutBuilt() {
		MainProgram tester = new MainProgram();
		tester.setWorkoutBuilt(true);
		assertEquals("Workout built must have been true", true, tester.getWorkoutBuilt());
		tester.setWorkoutBuilt(false);
		assertEquals("Workout built must havbe been false", false, tester.getWorkoutBuilt());
	}
	
	@Test
	public void testWorkoutComplete() {
		MainProgram tester = new MainProgram();
		tester.setworkoutComplete(true);
		assertEquals("Workout Complete must have been true", true, tester.getWorkoutComplete());
		tester.setworkoutComplete(false);
		assertEquals("Workout Complete must havbe been false", false, tester.getWorkoutComplete());
	}
	
	@Test
	public void testWorkoutSaved() {
		MainProgram tester = new MainProgram();
		tester.setWorkoutSaved(true);
		assertEquals("Workout Saved must have been true", true, tester.getWorkoutSaved());
		tester.setWorkoutSaved(false);
		assertEquals("Workout Saved must havbe been false", false, tester.getWorkoutSaved());
	}
	
	@Test
	public void testWorkoutStart() {
		MainProgram tester = new MainProgram();
		tester.setWorkoutStart(true);
		assertEquals("Workout Start must have been true", true, tester.getWorkoutStart());
		tester.setWorkoutStart(false);
		assertEquals("Workout Start must havbe been false", false, tester.getWorkoutStart());
	}
	
	@Test
	public void testWorkoutEnd() {
		MainProgram tester = new MainProgram();
		tester.setWorkoutEnd(true);
		assertEquals("Workout End must have been true", true, tester.getWorkoutEnd());
		tester.setWorkoutEnd(false);
		assertEquals("Workout End must havbe been false", false, tester.getWorkoutEnd());
	}
	
	@Test
	public void testWorkoutPause() {
		MainProgram tester = new MainProgram();
		tester.setWorkoutPause(true);
		assertEquals("Workout Pause must have been true", true, tester.getWorkoutPause());
		tester.setWorkoutPause(false);
		assertEquals("Workout Pause must havbe been false", false, tester.getWorkoutPause());
	}
}
